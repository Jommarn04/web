const express = require('express');
const path = require('path');
const cookieSession = require('cookie-session');
const bcrypt = require('bcrypt');
const dbConnection = require('./database');
const { body, validationResult } = require('express-validator');
const exp = require('constants');

const app = express();
app.use(express.urlencoded({ extended: false}))

app.set('Views', path.join(__dirname, 'Views'));
app.set('view engine', 'ejs');

app.use(cookieSession({
    name: "session",
    keys: ['key1', 'key2'],
    maxAge: 3600 * 1000 //1hr

}))

const ifNotLoggedIn = (req, res, next) => {
    if(!req.session.isLoggedIn){
        return res.render('login-register');
    }
    next();
}

const ifLoggedIn = (req, res, next) => {
    if(!req.session.isLoggedIn){
        return res.render('/home');
    }
    next();
}

app.get('/', ifNotLoggedIn, (req, res, next) =>{
    dbConnection.execute("SELECT username FROM user WHERE id = ?", [req.session.userID])
    .then(([rows]) => {
        res.render('home', {
            name: rows[0].name
        })
    })
})


app.post('/register', ifLoggedIn,[
    body('_email','Invalid Email Address!').isEmail().custom((value) => {
        return dbConnection.execute('SELECT email FROM user WHERE email = ?', [value])
        .then(([rows]) => {
            if(rows.length > 0 ) {
                return Promise.reject('This email alredy in use!');
            }
            return true;
        })
    }),
    body('_user', 'Username is empty!').trim().not().isEmpty(),
    body('_pass', 'The Password must be of minimun length 6 characters').trim().isLength({ min: 6}),

], 
    (req, res, next) => {
        const validation_result = validationResult(req);
        const { _user, _pass, _email} = req.body;

        if(validation_result.isEmpty()) {
            bcrypt.hash(_pass, 12).then((bcrypt.hash_pass) => {
                dbConnection.execute("INSERT INTO user (username, email,password) VALUES (?,?,?)", [_user, _email, hash_pass])
            })
        }
    })


app.listen(3000, () => console.log("Server is running...."))